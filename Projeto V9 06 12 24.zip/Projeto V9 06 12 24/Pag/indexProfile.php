Código html ->
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- GOOGLE FONTS -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <!-- FIM GOOGLE FONTS-->
    <!-- BOOTSTRAP ICONS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!-- FIM BOOTSTRAP ICONS -->
    <link rel="stylesheet" href="style.css">
    <title>▸ Meu Perfil</title>
</head>
<body>

    <header>
        <div class = "interface">
            <div class = "logo">
                <a href="#">
                    <img src = "images/foguetao.png" alt = "By Triangle Squad" class="imagem-foguetao">
                </a>
            </div>

            <nav class="icone-sininho">
                <ul>
                    <a href="#"><i class="bi bi-bell"></i></a>
                </ul>
            </nav>

        </div> <!-- Interface -->
    </header>

    <main>

        <section class="portfolio">
            <div class="interface">
                <div class="flex">
                    <div class="img-port" style="background-image: url(images/info.png);">
                        <div class="overlay">MINHAS INFORMAÇÕES</div>
                    </div>
                    <div class="img-port" style="background-image: url(images/info2.png);">
                        <div class="overlay">HISTÓRICO DE CHAMADOS</div>
                    </div>
                    <div class="img-port" style="background-image: url(images/info3.png);">
                        <div class="overlay">CONTATO COM SUPORTE</div>
                    </div>
                </div>
            </div> <!-- interface -->
        </section> <!-- portfolio -->


    </main>

    <footer>
        <div class="interface">
            <div class="line-footer">
                <div class="flex">
                    <div class="btn-social" hidden>
                        <a href="#"><button><i class="bi bi-instagram"></i></button></a>
                        <a href="#"><button><i class="bi bi-youtube"></i></button></a>
                        <a href="#"><button><i class="bi bi-linkedin"></i></button></a>
                    </div> <!-- btn-social -->
                </div> <!--  -->
            </div> <!-- line-footer-->

            <div class="line-footer borda">
                <p><i class="bi bi-envelope-fill"></i> <a href="mailto:contato@ficticio.com.br"></a></p>
            </div> <!-- line-footer-->
        </div> <!-- interface -->
    </footer>

</body>
</html>



        